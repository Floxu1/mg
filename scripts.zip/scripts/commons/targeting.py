from winstealer import *
from commons.skills import *
from commons.utils import *
import urllib3, json, urllib, ssl

clones = {
    "shaco": [0, False, False, "shaco_square"],
    "leblanc": [0, False, False, "leblanc_square"],
    "monkeyking": [0, False, False, "monkeyking_square"],
    "neeko": [0, False, False, "neeko_square"],
    "fiddlesticks": [0, False, False, "fiddlesticks_square"],
}



def effHP(game, target):
    global unitArmour, unitHP, debug_hp

    #target = GetBestTargetsInRange(game, e["Range"])
    unitArmour = target.armour
    unitHP = target.health

    return (
        (((1+(unitArmour / 100))*unitHP))
        )


ssl._create_default_https_context = ssl._create_unverified_context
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
def getPlayerStats():
    response = urllib.request.urlopen("https://127.0.0.1:2999/liveclientdata/activeplayer").read()
    stats = json.loads(response)
    return stats

def base_Damage(game):
    # Calculate raw R damage on target
    
    ad = getPlayerStats()["championStats"]["attackDamage"]
    


def GetBestTargetsInRange(game, atk_range=0):
    num = float("inf")
    target = None
    if atk_range == 0:
        atk_range = game.player.atkRange + game.player.gameplay_radius
    for champ in game.champs:
        if champ.name in clones and champ.R.name == champ.D.name:
            continue
        if champ.name=="kogmaw" or champ.name=="karthus":
            if not champ.health>0:
                continue
        if (

            # not champ.health>0
            not champ.is_alive
            or not champ.is_visible
            or not champ.isTargetable
            or champ.is_ally_to(game.player)
            or game.player.pos.distance(champ.pos) >= atk_range
        ):
            continue
        if num < champ.health:
            num = champ.health
            target = champ
       
        target = champ
        if IsImmobileTarget(champ):
            target = champ
        if is_last_hitable(game, game.player, champ):
            target = champ
    if target:
        return target

# def Largeminion(game,atk_range=0):
#     num = 999999999
#     target = None
#     ad = getPlayerStats()["championStats"]["attackDamage"]
#     if atk_range == 0:
#         atk_range = game.player.atkRange + game.player.gameplay_radius + 25
#     for minion in game.minions:
#         if (
#             not minion.is_alive
#             or not minion.is_visible
#             or not minion.isTargetable
#             or minion.is_ally_to(game.player)
#             or game.player.pos.distance(minion.pos) >= atk_range
#         ):
#             continue
#         if ad>=minion.health and minion.name=="sru_chaosminionsiege":
#             target=minion
#         if is_last_hitable(game, game.player, minion):
#             target = minion
#     return target

def GetBestMinionsInRange(game, atk_range=0):
    num = 999999999
    target = None
    if atk_range == 0:
        atk_range = game.player.atkRange + game.player.gameplay_radius + 25
    for minion in game.minions:
        if (
            not minion.is_alive
            or not minion.is_visible
            or not minion.isTargetable
            or minion.is_ally_to(game.player)
            or game.player.pos.distance(minion.pos) > atk_range
        ):
            continue
        # target=minion
        hpPercent = minion.health / minion.max_health * 100
        if is_last_hitable(game, game.player, minion) or num >= minion.health:
            num = minion.health
            target = minion
    if target:
        return target


def GetBestJungleInRange(game, atk_range=0):
    num = 999999999
    target = None
    if atk_range == 0:
        atk_range = game.player.atkRange + game.player.gameplay_radius + 25
    for jungle in game.jungle:
        if (
            not jungle.is_alive
            or not jungle.is_visible
            or not jungle.isTargetable
            or jungle.is_ally_to(game.player)
            or game.player.pos.distance(jungle.pos) > atk_range
        ):
            continue
        if num >= jungle.health:
            num = jungle.health
            target = jungle
        if is_last_hitable(game, game.player, jungle):
            target = jungle
    return target


def GetBestTurretInRange(game, atk_range=0):
    target = None
    if atk_range == 0:
        atk_range = game.player.atkRange + game.player.gameplay_radius + 25
    for turret in game.turrets:
        if (
            not turret.is_alive
            or not turret.is_visible
            or not turret.isTargetable
            or turret.is_ally_to(game.player)
            or game.player.pos.distance(turret.pos) > atk_range
        ):
            continue
        return turret



def LastHitMinions(game,atk_range=0):
    num = float("inf")
    target = []
    ad=game.player.base_atk + game.player.bonus_atk
    
    # ad = getPlayerStats()["championStats"]["attackDamage"]

    if atk_range == 0:
        atk_range = game.player.atkRange + game.player.gameplay_radius + 50
    for minion in game.minions:
        if (
            not minion.is_alive
            or not minion.is_visible
            or not minion.isTargetable
            or minion.is_ally_to(game.player)
            or game.player.pos.distance(minion.pos) >= atk_range
        ):
            continue
        # if ad>=minion.health:
        #     target=minion
            
        
        if is_last_hitable(game, game.player, minion):
            target=minion
    return target


def GetAllyMinionsInRange(game, atk_range=0):
    target = None
    if atk_range == 0:
        atk_range = game.player.atkRange + game.player.gameplay_radius + 25
    for minion in game.minions:
        if (
            not minion.is_alive
            or not minion.is_visible
            or not minion.isTargetable
            or minion.is_enemy_to(game.player)
            or game.player.pos.distance(minion.pos) >= atk_range
        ):
            continue
        target = minion
    if target:
        return target


def GetAllyChampsInRange(game, atk_range=0):
    target = None
    if atk_range == 0:
        atk_range = game.player.atkRange + game.player.gameplay_radius + 25
    for champ in game.champs:
        if (
            not champ.is_alive
            or not champ.is_visible
            or not champ.isTargetable
            or champ.is_enemy_to(game.player)
            or game.player.pos.distance(champ.pos) >= atk_range
        ):
            continue
        target = champ
    if target:
        return target
